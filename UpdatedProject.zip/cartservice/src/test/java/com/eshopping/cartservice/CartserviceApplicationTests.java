package com.eshopping.cartservice;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.eshopping.cartservice.model.Cart;
import com.eshopping.cartservice.model.CartItem;
import com.eshopping.cartservice.repository.CartRepository;
import com.eshopping.cartservice.repository.OrderRepository;
import com.eshopping.cartservice.service.CartServiceImpl;
import com.eshopping.cartservice.service.OrderServiceImpl;


@SpringBootTest
class CartserviceApplicationTests {

	@Autowired
	private CartServiceImpl cartServiceImpl;
	
	@Autowired
	private OrderServiceImpl orderServiceImpl;
	
	@MockBean
	CartRepository cartRepository;
	
	@MockBean
	OrderRepository orderRepository;
	
	@Test
	public void createCartTest() {
		List<CartItem> cartItems = new ArrayList<>();
		cartItems.add(new CartItem("6783738","Garlic Powder","Spices","Even if you choose to use fresh garlic on a regular basis, having garlic powder around can be beneficial too. It’s a great way to add some quick garlic flavor to a dish or you can use it to mix into your own spice blends.",800,"https://t4.ftcdn.net/jpg/02/21/82/75/360_F_221827508_W6u2m8vZGbi0nfxvhxF8GGrDZ04lmFj9.jpg",2));
		cartItems.add(new CartItem("8484848","Thyme","Spices","Thyme is woodsy, lemony and mild. It is most often used as a flavor for meats and stews, but it can add some zing to vegetables as well.",700,"https://cdn.create.vista.com/api/media/small/268900326/stock-photo-top-view-green-thyme-wooden",2));
		Cart cart = new Cart("282282","232332",cartItems,1500);
		cartServiceImpl.createNewCart(cart);
		verify(cartRepository,times(1)).save(cart);
	}
	
	@Test
	public void findCartByUserIdTest(){
		List<CartItem> cartItems = new ArrayList<>();
		cartItems.add(new CartItem("6783738","Garlic Powder","Spices","Even if you choose to use fresh garlic on a regular basis, having garlic powder around can be beneficial too. It’s a great way to add some quick garlic flavor to a dish or you can use it to mix into your own spice blends.",800,"https://t4.ftcdn.net/jpg/02/21/82/75/360_F_221827508_W6u2m8vZGbi0nfxvhxF8GGrDZ04lmFj9.jpg",2));
		cartItems.add(new CartItem("8484848","Thyme","Spices","Thyme is woodsy, lemony and mild. It is most often used as a flavor for meats and stews, but it can add some zing to vegetables as well.",700,"https://cdn.create.vista.com/api/media/small/268900326/stock-photo-top-view-green-thyme-wooden",2));
		Optional<Cart> cart = Optional.of(new Cart("282282","232332",cartItems,1500));
		String cartId = "282282";
		when(cartRepository.findCartByUserId(cartId)).thenReturn(cart);
	}
	
	@Test
	public void findOrdersByUserId() {
	}

}
