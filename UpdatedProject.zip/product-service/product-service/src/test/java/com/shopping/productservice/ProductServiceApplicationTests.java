package com.shopping.productservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.shopping.productservice.model.Products;
import com.shopping.productservice.service.ProductServiceImpl;
import com.shopping.productservice.service.repository.ProductRepository;

@SpringBootTest
class ProductServiceApplicationTests {
	
    @Autowired
	private ProductServiceImpl productServiceImpl;
    
    @MockBean
    private ProductRepository productRepository;
    
    @Test
    public void getAllProductsTest(){
    	when(productRepository.findAll()).thenReturn(Stream
    			.of(new Products("23","Wheat","Grains","Fine grain",900,"https://wallpapercave.com/wp/wp1886336.jpg"), 
    					new Products("110","Rice","Grains","Fine Grains",9900,"https://wallpaperaccess.com/full/1463520.jpg")).collect(Collectors.toList()));
    	
    	assertEquals(2, productServiceImpl.getAllProducts().size());
    }
    
    @Test
    public void getProductsByCategory() {
    	String category = "Pulses";
    	when(productRepository.findProductByCategory(category)).thenReturn(Stream
    			.of(new Products("321","Yellow split Pigeon peas","Pulses","Fine Pulses",900,"https://ak.picdn.net/shutterstock/videos/1082062859/thumb/10.jpg?ip=x480"), 
    					new Products("321","Yellow split Pigeon peas","Pulses","Fine Pulses",9900,"https://ak.picdn.net/shutterstock/videos/1082062859/thumb/10.jpg?ip=x480")).collect(Collectors.toList()));
    	assertEquals(2, productServiceImpl.findProductsByCategory(category).size());
    }
    
    @Test
    public void addProductTest() {
    	Products product = new Products("123","Black Pepper","Spices","The great pepper from punjab",700,"https://cdn.pixabay.com/photo/2020/11/16/14/40/black-pepper-5749131__340.jpg");
    	productServiceImpl.addProduct(product);
    	verify(productRepository,times(1)).save(product);
    	
    }
    @Test
    public void deleteProductTest() {
    	String id = "999";
    	productServiceImpl.deleteProduct(id);
    	verify(productRepository,times(1)).deleteById(id);
    	
    }
}
